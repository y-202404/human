
INSERT INTO article(title, content) VALUES('시스템 개선 및 서비스 점검 안내', '1111');
INSERT INTO article(title, content) VALUES('브런치 유어 웨이 이벤트 종료 사전 안내', '2222');
INSERT INTO article(title, content) VALUES('시스템 개선 및 서비스 점검 안내', '3333');

INSERT INTO article(title, content) VALUES('일부 품목 가격 조정 안내', '댓글 고');
INSERT INTO article(title, content) VALUES('시스템 개선 및 서비스 점검 안내', '댓글 고고');
INSERT INTO article(title, content) VALUES('스타벅스 카드 이용약관 일부 정정 안내', '댓글 고고고');

