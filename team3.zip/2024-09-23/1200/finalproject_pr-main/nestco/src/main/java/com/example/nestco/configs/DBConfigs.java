package com.example.nestco.configs;

public class DBConfigs {
}
