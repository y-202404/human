package com.example.nestco.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model; // 마우스로 추가 
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ArticleController {

    @GetMapping("/hi")
    public String nice(Model model ) {
        model.addAttribute("username", "youngjoon");
        return "greeting"; // 템플릿/그리팅 -> 브라우저로 전송
    }

    @GetMapping("/bye")
    public String nice2(Model model ) {
        model.addAttribute("username", "youngjoon");
        return "greeting"; // 템플릿/그리팅머스테치 -> 브라우저로 전송
    }
}
