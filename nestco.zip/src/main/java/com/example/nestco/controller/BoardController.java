package com.example.nestco.controller;

import com.example.nestco.dto.BoardForm;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model; // 마우스로 추가 
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class BoardController {

    @GetMapping("/board/new")
    public String newBoardForm(Model model) {
        model.addAttribute("username", "youngjoon");
        return "board/new"; // 템플릿/그리팅 -> 브라우저로 전송
    }
    @PostMapping("/board/create")
    public String createBoard(BoardForm form) {
        System.out.println(form.toString());
        return "";
    }

}
