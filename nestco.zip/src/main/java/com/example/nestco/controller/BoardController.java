package com.example.nestco.controller;


import com.example.nestco.Entity.Board;
import com.example.nestco.dto.BoardForm;
import com.example.nestco.repository.BoardRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;


@Controller
@Slf4j //로깅 사용
public class BoardController {

    @Autowired //스프링부트가 미리 생성해놓은 객체를 가져다가 자동연결
    private BoardRepository boardRepository;

    @GetMapping("/board/new")
    public String newBoardForm() {
        return"board/new";
    }

    @PostMapping("/board/create")
    public String createBoardForm(BoardForm form ){ //파라메터디티오
        //System.out.println(form.toString());
        log.info(form.toString());


        //1. 디티오를 엔티티로 변환
        Board board = form.toEntity();
        //System.out.println(board.toString());
        log.info(board.toString());

        //2. 레파지토리에게 엔티티를 디비 안에 저장
        Board saved = boardRepository.save(board);
        //System.out.println(saved.toString());
        log.info(saved.toString());

        //3.
        return "redirect:/board/" + saved.getId();
    }

    @GetMapping("/board/{id}")
    public String show(@PathVariable Long id, Model model) {
        log.info("id = " + id);

        //1. id로 데이터를 가져옴
        Board boardEntity = boardRepository.findById(id).orElse(null);
        //2. 가져온 데이터를 모델에 등록
        model.addAttribute("board", boardEntity);
        //3. 보여줄 페이지를 설정
        return "board/show";
    }

    @GetMapping("/board")
    public String index(Model model) {

        //1. 모든 보드를 가져온다
        List<Board> boardEntitiyList = boardRepository.findAll();
        //Iterable<Board> boardEntitiyList = boardRepository.findAll();

        //2. 가져온 보드 묶음을 뷰로 전달
        model.addAttribute("boardList",boardEntitiyList);
        
        //3. 뷰페이지를 실행
        
        return "board/index"; //보드/인텍스.머스테치
    }

    @GetMapping("/board/{id}/edit")
    public String edit(@PathVariable Long id, Model model) {
        //수정할 데이터를 가져오기
        Board boardEntity = boardRepository.findById(id).orElse(null);

        //모델에 데이터를 등록
        model.addAttribute("board", boardEntity);

        //뷰 페이지 설정
        return "board/edit";
    }

    @PostMapping("/board/update")
    public String update(BoardForm form) {

        //1. 디티오를 엔티티로 변환
        Board boardEntity = form.toEntity();
        log.info(boardEntity.toString());

        //2. 엔티티를 디비로 저장 기존데이터 가져온후 값을 수정 갱신한다
        Board target = boardRepository.findById(boardEntity.getId()).orElse(null);
        if( target != null)
            boardRepository.save(boardEntity);
        //3. 수정 결과 페이지로 리다이렉트
        return "redirect:/board/" + boardEntity.getId();
    }
}
