package com.example.nestco.dto;

import java.beans.ConstructorProperties; //생성자의 파라미터를 명시적으로 지정

public class BoardForm {


    private String username;
    private String title;
    private String content;

    @ConstructorProperties({"username", "title", "content"}) // 파라미터 이름 명시
    public BoardForm(String username, String title, String content) { //생성자생성
        this.username = username;
        this.title = title;
        this.content = content;
    }

    @Override
    public String toString() {
        return "BoardForm{" +
                "username='" + username + '\'' +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                '}';
    }

}
