package com.example.nestco.dto;

import com.example.nestco.Entity.Board;
import lombok.AllArgsConstructor;
import lombok.ToString;


@AllArgsConstructor //1번 대체 어노테이션
@ToString //2번 대체 어노테이션
public class BoardForm {

    //public Board toEntity;
    private Long id;
    private String title;       //필드
    public  String content;

    //1번
//    public BoardForm(String title, String content) {
//        this.title = title;
//        this.content = content;
//    }

    //2번
//    @Override
//    public String toString() {
//        return "BoardForm{" +
//                "title='" + title + '\'' +
//                ", content='" + content + '\'' +
//                '}';
//    }

    public Board toEntity() {
        return  new Board(id, title, content);
    }
}
