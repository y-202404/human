package com.example.nestco.Repository;

import com.example.nestco.entity.Article;
import org.springframework.data.repository.CrudRepository;

public interface ArticleRepository extends CrudRepository<Article, Long> {//관리대상,대표값의타입 {
}
