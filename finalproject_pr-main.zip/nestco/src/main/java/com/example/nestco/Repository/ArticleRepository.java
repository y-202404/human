package com.example.nestco.Repository;

import com.example.nestco.entity.Article;
import org.springframework.data.repository.CrudRepository;

import java.util.ArrayList;

public interface ArticleRepository extends CrudRepository<Article, Long> {
    @Override
    ArrayList<Article> findAll();//관리대상,대표값의타입

}
