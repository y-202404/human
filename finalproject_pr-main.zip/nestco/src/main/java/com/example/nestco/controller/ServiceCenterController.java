package com.example.nestco.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller

public class ServiceCenterController {

    @GetMapping("/notice")
    public String Notice(Model model) {
        model.addAttribute("username", "전영준");
        return "Notice";
    }

    @GetMapping("/editnotice")
    public String EditNoice(Model model) {
        model.addAttribute("username", "전영준");
        return "EditNotice";
    }

    @GetMapping("/oneonone")
    public String OneOnOne(Model model) {
        model.addAttribute("username", "전영준");
        return "OneOnOne";
    }

    @GetMapping("/editoneonone")
    public String EditOneOnOne(Model model) {
        model.addAttribute("username", "전영준");
        return "EditOneOnOne";
    }

    @GetMapping("/userguide")
    public String UserGuide(Model model) {
        model.addAttribute("username", "전영준");
        return "UserGuide";
    }

}