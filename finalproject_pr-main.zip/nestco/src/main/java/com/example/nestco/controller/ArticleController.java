package com.example.nestco.controller;

import com.example.nestco.Repository.ArticleRepository;
import com.example.nestco.dto.ArticleForm;
import com.example.nestco.entity.Article;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
@Slf4j // 로깅을 위해 필요
public class ArticleController {

    @Autowired //스프링부트가 알아서 해줌
    private ArticleRepository articleRepository;

    @GetMapping("/articles/new")
    public String newArticleForm() {
        return "articles/new";
    }

    @PostMapping("articles/create")
    public String createArticle(ArticleForm form) {
        log.info(form.toString());
      //  System.out.println(form.toString());  // 기록에 남지도 않고 서버에도 부담이라 사용 안함 .로깅으로 대체
        //로깅 ->  서버에서 일어나는 일들을 다 기록

        // dto를 변환 .entity로
        Article article = form.toEntity();
        log.info(article.toString());
        //System.out.println(article.toString());

       // 레파지토리에게 엔티티를 디비안에 저장
        Article saved = articleRepository.save(article);
        log.info(saved.toString());
        //System.out.println(saved.toString());
        return "redirect:/articles/" + saved.getId();
    }

    @GetMapping("/articles/{id}")
    public String show(@PathVariable Long id, Model model) {
        log.info("id = " + id);

        //1. id로 데이터를 가져옴
        Article articleEntity = articleRepository.findById(id).orElse(null);

        //2.뷰페이지에 사용하기위해  가져온걸 모델에 등록
        model.addAttribute("article", articleEntity);

        //3. 보여줄 페이지 설정

        return "articles/show";
    }

    @GetMapping("/articles")
    public String index(Model model) {
        //1. 모든 article 가져옴
        List<Article>articleEntityList = (List<Article>)articleRepository.findAll();
         // 또는 Iterable<Article>articleEntityList = articleRepository.findAll();

        //2. article 묶음을 뷰로
    model.addAttribute("articleList", articleEntityList);

        //3. 뷰 페이지 설정

    return "articles/index"; //articles/index.mustache
    }

    @GetMapping("/articles/{id}/edit")
    public String edit(@PathVariable Long id, Model model) {
        //수정 데이터 가져오기
        Article articleEntity = articleRepository.findById(id).orElse(null);
        //뷰페이지 설정
        model.addAttribute("article", articleEntity);

        return "articles/edit";

    }
    @PostMapping("/articles/edit")
    public String update(ArticleForm form) { //dto

        log.info(toString());

        //1. dto를 entity로 변환
         Article articleEntity = form.toEntity();
         log.info(toString());

        //2.entity를 디비에 저장

        Article target = articleRepository.findById(articleEntity.getId()).orElse(null);
        if (target != null) {
            articleRepository.save(articleEntity);
        }


        //3. 수정 리다이렉트

        return "redirect:/articles/" + articleEntity.getId();

    }
}
