package com.example.nestco.controller;

import com.example.nestco.Repository.ArticleRepository;
import com.example.nestco.dto.ArticleForm;
import com.example.nestco.entity.Article;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
@Slf4j // 로깅을 위해 필요
public class ArticleController {

    @Autowired //스프링부트가 알아서 해줌
    private ArticleRepository articleRepository;

    @GetMapping("/articles/new")
    public String newArticleForm() {
        return "articles/new";
    }

    @PostMapping("articles/create")
    public String createArticle(ArticleForm form) {
        log.info(form.toString());
      //  System.out.println(form.toString());  // 기록에 남지도 않고 서버에도 부담이라 사용 안함 .로깅으로 대체
        //로깅 ->  서버에서 일어나는 일들을 다 기록

        // dto를 변환 .entity로
        Article article = form.toEntity();
        log.info(article.toString());
        //System.out.println(article.toString());

       // 레파지토리에게 엔티티를 디비안에 저장
        Article saved = articleRepository.save(article);
        log.info(saved.toString());
        //System.out.println(saved.toString());
        return "";

    }
}
