package com.example.nestco.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller

public class CommunityBoardController {

    @GetMapping("/cummunityboard")
    public String CommunityBoard(Model model) {
        model.addAttribute("username", "전영준");
        return "CommunityBoard";
    }

    @GetMapping("/editcummunityboard")
    public String EditCommunityBoard(Model model) {
        model.addAttribute("username", "전영준");
        return "EditCommunityBoard";
    }

}