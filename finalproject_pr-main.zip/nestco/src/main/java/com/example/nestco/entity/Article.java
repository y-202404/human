package com.example.nestco.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.ToString;

@Entity
@AllArgsConstructor // 롬복으로 1번 대신함
@ToString // 롬복으로 2번 대신함
public class Article {

    @Id //대표값지정
    @GeneratedValue //자동생성
    private Long id;
    
    @Column
    private String title;

    @Column
    private String content;

    //1번
//    public Article(Long id, String title, String content) {
//        this.id = id;
//        this.title = title;
//        this.content = content;
//    }

    //2번
//    @Override
//    public String toString() {
//        return "Article{" +
//                "id=" + id +
//                ", title='" + title + '\'' +
//                ", content='" + content + '\'' +
//                '}';
//    }
}
