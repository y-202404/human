package com.example.nestco.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Entity
@AllArgsConstructor // 롬복으로 1번 대신함
@ToString // 롬복으로 2번 대신함
@NoArgsConstructor //3번 디폴트 생성자 추가
@Getter //4번
public class Article {

    @Id //대표값지정
    @GeneratedValue //(strategy = GenerationType.IDENTITY) //자동생성
    private Long id;
    
    @Column
    private String title;

    @Column
    private String content;

    @Column
    private String name;

    @Column
    private LocalDateTime date;

    @PrePersist
    public void prePersist() {
        if(this.date ==null) {
        this.date = LocalDateTime.now();
        }
    }

    // date를 현재시간으로 수정

    @PreUpdate
    public void preUpdate(){
        this.date = LocalDateTime.now();
    }

    // date 가 null 이 아닌경우만 반환, null일 경우 그대로
    public String newdate() {
        if(this.date !=null) {
            return date.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        } else {
            return "no date";
        }
        }


    //4번
    //public String getId() {
    //    return Long id;
   // }

    //3번
    //Article(){
        
    //}


    //1번
//    public Article(Long id, String title, String content) {
//        this.id = id;
//        this.title = title;
//        this.content = content;
//    }

    //2번
//    @Override
//    public String toString() {
//        return "Article{" +
//                "id=" + id +
//                ", title='" + title + '\'' +
//                ", content='" + content + '\'' +
//                '}';
//    }
}
