package com.example.nestco.dto;

import com.example.nestco.entity.Article;
import lombok.AllArgsConstructor;
import lombok.ToString;

@AllArgsConstructor   // 롬복사용으로 1번이랑 똑같다
@ToString // 롬복사용으로 2번이랑 똑같다
public class ArticleForm {

    private String title;
    private String content;

    //1번
//    public ArticleForm(String title, String content) {
//        this.title = title;
//        this.content = content;
//    }

    //2번
//    @Override
//    public String toString() {
//        return "ArticleForm{" +
//                "title='" + title + '\'' +
//                ", content='" + content + '\'' +
//                '}';
//    }

    public Article toEntity() { //entity인 article을 반환
        return new Article(null, title, content);
    }
}
