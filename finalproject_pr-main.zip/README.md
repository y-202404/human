# finalproject_pr

https://www.figma.com/design/gyTK18yEAKDpr3FSzd5fIw/%EC%8B%A4%EC%8A%B51?node-id=2-3&t=YbNyxYZ5O7OgjcdW-1
