package com.example.nestco.Entity;

import com.example.nestco.repository.BoardRepository;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;


@Entity // 디비 가 해당객체를 인식 가능
@AllArgsConstructor //1번 대체 어노테이션
@ToString //2번 대체 어노테이션
@NoArgsConstructor //디폴트생성자를 추가해주는 어노테이션
@Getter //모든 get 추가
public class Board {

    @Id //대표값 지정
    @GeneratedValue // 자동생성
    private Long id;

    @Column
    private String title;

    @Column
    public  String content;

//    public Long getId() {
//        return id;
//    }

//    Board() {   //디폴트생성자
//
//    }

    //1번
//    public Board(Long id, String title, String content) {
//        this.id = id;
//        this.title = title;
//        this.content = content;
//    }

//2번
//    @Override
//    public String toString() {
//        return "Board{" +
//                "id=" + id +
//                ", title='" + title + '\'' +
//                ", content='" + content + '\'' +
//                '}';
//    }

}
