package com.example.nestco.repository;

import com.example.nestco.Entity.Board;
import org.springframework.data.repository.CrudRepository;

import java.util.ArrayList;

public interface BoardRepository extends CrudRepository<Board,Long> { //관리대상엔티티 , 대표값타입


    @Override
    ArrayList<Board> findAll();
}
