package com.example.nestco.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.query.sql.internal.ParameterRecognizerImpl;

@Entity
@Getter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Comment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne // 해당 댓글 엔티티 여러개가 하나의 보드에 연관
    @JoinColumn(name = "board_id") //board_id 컬럼에 board 의 대표값을 저장
    private Board board;

    @Column
    private  String name;
    @Column
    private  String body;
}
